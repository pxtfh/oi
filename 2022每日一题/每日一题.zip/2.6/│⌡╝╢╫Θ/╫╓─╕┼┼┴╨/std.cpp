#include<bits/stdc++.h>
using namespace std;
char a[100001],b[100001];
int main() 
{
//	freopen("t.in","r",stdin);
//	freopen("t.out","w",stdout);
	scanf("%s",a);
	scanf("%s",b);
	int la=strlen(a),lb=strlen(b),num_a,num_b;
	char ta,tb;
	for(int i=la-1;i>=0;i--){
		for(int j=0;j<lb;j++){
			if(a[i]==b[j]){
				num_a=i;
				num_b=j;//��¼��ͬ��ĸ��λ��
				ta=a[i];
				tb=b[j];//��¼��ͬ��ĸ 
				break;
			}
		}
	}
	for(int j=0;j<lb;j++){
		if(j==num_b){
			for(int k=0;k<=la;k++){
				cout<<a[k];
			}
		}
		else for(int i=0;i<la;i++){
			if(i!=num_a){
				cout<<".";
			}
			else if(i==num_a){
				cout<<b[j];
			}
		}
		cout<<endl;
	}
	return 0;
}
