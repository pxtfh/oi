#include<bits/stdc++.h>
using namespace std;
const int maxn=105;
int n;
bool a[maxn]; 
int main()
{
// 	freopen("t.in","r",stdin);
	freopen("t.out","w",stdout);
	cin>>n;
	cout<<n<<endl;
	for(int i=1;i<=n;i++)
	{
		for(int j=1;j<=n;j++)
		{
			if(i!=j)
				a[j]=!a[j];
			cout<<a[j];
		}
		cout<<endl;
	}
	return 0;
}
