#include<algorithm>
#include<cstdio>
#include<cstring>
#include<iostream>
using namespace std;
typedef long long int ll;
ll f[200][90][90];
int m,n;
ll a[90][90];
ll maxn(ll x,ll y,ll c,ll d)
{
	ll temp1=max(x,y);
	ll temp2=max(c,d);
	return max(temp1,temp2); 
}
int main(void)
{
	freopen("ɢ��.in","r",stdin);
	freopen("ɢ��.out","w",stdout); 
	scanf("%d%d",&n,&m);
	for(int i=1;i<=n;i++)
		for(int j=1;j<=m;j++)
			scanf("%d",&a[i][j]);
	for(int st=1;st<n+m-2;st++)
		for(int i=1;i<min(st+1,n);i++)
			for(int j=i+1;j<=min(st+1,n);j++)
			{
				f[st][i][j]=maxn(f[st-1][i][j],f[st-1][i-1][j],f[st-1][i][j-1],f[st-1][i-1][j-1])+a[i][st+2-i]+a[j][st+2-j];	
			}
	 printf("%d",f[n+m-3][n-1][n]);
	 return 0;
} 
