#include<bits/stdc++.h>
using namespace std;
int n,m;
long long a,sum,maxT;
int main()
{
	freopen("1.in","r",stdin);
	freopen("1.out","w",stdout);
    cin>>n>>m;
    for(int i=1;i<=n;i++)
	{
        cin>>a;
        sum+=a;
        maxT=max(maxT,a);
    }
    maxT=max(maxT,((sum+m-1)/m));
    cout<<maxT<<endl;
    return 0;
}
