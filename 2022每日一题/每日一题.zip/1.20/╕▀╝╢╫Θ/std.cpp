#include<bits/stdc++.h>
using namespace std;
int a[100086],n,m;
int main()
{
	scanf("%d%d",&n,&m);
	for(int i=0;i<n;i++)
	{
		scanf("%d",a+i);
		a[i]=min(a[i],m-a[i]);
	}
	sort(a,a+n);
	printf("%d %d\n",a[n-1],m-a[0]);
	return 0;
}
