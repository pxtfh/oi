#include<bits/stdc++.h>
using namespace std;
int n;
int main(){
//	freopen("t.in","r",stdin);
//	freopen("t.out","w",stdout);
    cin>>n;
    cout<<(int)log2(n)+1;
    return 0;
}
