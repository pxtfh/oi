#include<bits/stdc++.h>
using namespace std;
long long t,n,a[1024]={1};
int main()
{
	for(int i=1;a[i-1]<1e17;i++)
		a[i]=a[i-1]*(4*i-2)/(i+1);
	cin>>t;
	while(t--)
	{
		cin>>n;
		cout<<a[n]<<endl;
	}
	return 0;
} 
