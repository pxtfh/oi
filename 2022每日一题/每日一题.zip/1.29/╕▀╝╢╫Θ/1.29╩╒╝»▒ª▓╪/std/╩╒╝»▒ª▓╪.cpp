#include<iostream>
#include<cstdio>
#include<algorithm>
using namespace std;
int w[10005],v[10005],f[10005];
int N,M;
void func(int n,int m)
{
	for(int i=1;i<=m;i++)
	{
		for(int j=n;j>=1;j--)
		{
			if(w[i]<=j){
				f[j]=max(f[j],f[j-w[i]]+v[i]);
			}
		}
	}
	printf("%d",f[n]);
	return;
}
int main(void)
{
	freopen("�ռ�����.in","r",stdin);
	freopen("�ռ�����.out","w",stdout);
	scanf("%d%d",&N,&M);
	for(int i=1;i<=M;i++)
	{
		scanf("%d%d",&w[i],&v[i]);
	 } 
	func(N,M);
	return 0;
}
