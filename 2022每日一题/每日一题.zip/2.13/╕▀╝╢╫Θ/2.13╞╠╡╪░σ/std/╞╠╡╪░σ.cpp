#include<iostream>
using namespace std;
typedef unsigned long long int ull;
ull f[35];
int main()
{
	freopen("a.in","r",stdin);
	freopen("a.out","w",stdout);
    f[0]=1;
    int n;
    cin >> n;
    for(int i=1;i<=n;i++){
        f[i]=f[i-1]*(4*i-2)/(i+1);
    }
	cout<<f[n]<<endl;
    return 0;
}

