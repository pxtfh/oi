#include<bits/stdc++.h>
using namespace std;
int a[200][6];
int n;
int main()
{
//	freopen("t.in","r",stdin);
//	freopen("t.out","w",stdout);
	cin>>n;
	for(int i=1;i<=199;i++)
		a[i][5]=5;
	for(int p=0;p<n;p++)
	{
		int b;
		cin>>b;
		for(int i=1;i<=n;i++)
		{
			if(a[i][5]<b)continue;
			for(int j=0;j<5;j++)
			{
				if(!a[i][j])
				{
					for(int k=j;k<j+b;k++)
					{
						a[i][k]=1;
						cout<<(i-1)*5+k+1<<" ";
					}
					break;
				}
			}
			a[i][5]-=b;
			break;
		}	
		cout<<endl;
	}
	return 0;
}

