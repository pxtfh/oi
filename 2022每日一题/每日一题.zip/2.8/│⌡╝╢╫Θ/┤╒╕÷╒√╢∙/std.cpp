#include <iostream>
using std::cin;
using std::cout;
// շת�����gcd
int gcd(int m, int n) { return n ? gcd(n, m % n) : m; }
int d;
int x[100010];
int main()
{
	freopen("t.in","r",stdin);
	freopen("t.out","w",stdout);
    cin >> d;
    while (d--)
    {
        int n;
        cin >> n;
        for (int i = 1; i <= n; i++)
            cin >> x[i];
        x[2] /= gcd(x[2], x[1]);
        for (int i = 3; i <= n; i++)
            x[2] /= gcd(x[2], x[i]);
        if (x[2] == 1)
            cout << "YES\n";
        else
            cout << "NO\n";
    }
    return 0;
}
