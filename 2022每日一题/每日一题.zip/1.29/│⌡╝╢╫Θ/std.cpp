#include<bits/stdc++.h>
using namespace std;
int n;
struct stu{
	int num;
	int c,m,e;
	int sum;
}student[305];
bool cmp(stu a,stu b)
{
	if(a.sum>b.sum)
	    return true;
	if(a.sum<b.sum)
	    return false;
    if(a.c>b.c)
        return true;
	if(a.c<b.c)
	    return false;
	if(a.num<b.num)
	    return true;
	else
	    return false;
 		 
}
int main()
{
   freopen("P1093.in","r",stdin);
   //freopen(".out","w",stdout);
   //ios::sync_with_stdio(0);
   cin>>n;
   for(int i=1;i<=n;i++)
   {
   	    student[i].num=i;
   	    cin>>student[i].c>>student[i].m>>student[i].e;
   	    student[i].sum=student[i].c+student[i].m+student[i].e;
   }
   sort(student+1,student+n+1,cmp);
   for(int i=1;i<=5;i++)
       cout<<student[i].num<<' '<<student[i].sum<<endl;
   return 0;
}



