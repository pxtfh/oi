#include<iostream> 
#include<algorithm>
using namespace std;
const int MAXN=1000005;
struct NODE{
	int l,r;
}node[MAXN];
bool cmp(NODE a,NODE b){
	return a.r<b.r;
}
int main(void){
	freopen("a.in","r",stdin);
	freopen("a.out","w",stdout);
	int n;
	cin>>n;
	for(int i=1;i<=n;i++){
		cin>>node[i].l>>node[i].r;
	}
	sort(node+1,node+1+n,cmp);
	int p=-1,ans=0;
	for(int i=1;i<=n;i++){
		if(p>=node[i].l) continue;
		ans++;
		p=node[i].r;
	}
	cout<<ans<<endl;
}
