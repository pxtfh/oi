#include<bits/stdc++.h>
using namespace std;
struct node 
{
	int num;
	string name;
	double ave;
}o[20000];
int n;
int cmp(node a,node b)
{
	
	if(a.ave==b.ave)return a.num<b.num;
	else return a.ave>b.ave;
}
int main()
{
	freopen("t.in","r",stdin);
	freopen("t.out","w",stdout);
	cin>>n;
	for(int i=0;i<n;i++)
	{
		int a,b,c;
		cin>>o[i].num;
		cin>>o[i].name;
		cin>>a>>b>>c;
		o[i].ave=(a+b+c)/3.0;
	}
	sort(o,o+n,cmp);
	for(int i=0;i<n;i++)
	{
		cout<<o[i].num<<" ";
		cout<<o[i].name<<" ";
		printf("%.1llf\n",o[i].ave);
	}
	return 0;
}

