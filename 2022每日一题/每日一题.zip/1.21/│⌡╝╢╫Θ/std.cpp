#include<bits/stdc++.h>
using namespace std;
string a,e="ed",f="ing",g="ly";
int n; 
int main()
{
	freopen("t2.in","r",stdin);
	freopen("t2.out","w",stdout);
	ios::sync_with_stdio(0);
	cin>>n;
	for(int i=1;i<=n;i++)
	{
		cin>>a;
		int sizen=a.size();
		int o=a.rfind("ed");
		int p=a.rfind("ing");
		int q=a.rfind("ly");
		if(sizen-2==o)
		{
			a.erase(o,2);
			cout<<a<<endl;
		}
		else
		{
			if(sizen-3==p)
			{
				a.erase(p,3);
				cout<<a<<endl;
			}
			else
			{
				if(sizen-2==q)
				a.erase(q,2);
				cout<<a<<endl;
			}
		}
	}
	return 0;
}

