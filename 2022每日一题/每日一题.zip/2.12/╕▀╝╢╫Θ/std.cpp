#include<bits/stdc++.h>
using namespace std;
int a[100500],S[200500];
char s[100500];
int main()
{
	int n;
	scanf("%d",&n);
	scanf("%s",s+1);
	memset(S,-1,sizeof(S));
	for(int i=1;i<=n;i++)
	{
		if(s[i]=='0')
			a[i]=a[i-1]-1;
		if(s[i]=='1')
			a[i]=a[i-1]+1;
	}
	int num=0;
	for(int j=0;j<=n;j++)
		if(S[a[j]+n]==(-1))
			S[a[j]+n]=j;
		else
			num=max(num,(j-S[a[j]+n]));
	printf("%d\n",num);
	return 0;
}
