#include<iostream>
#include<cstdio>
#include<algorithm>
using namespace std;
int f[100005],w[10005],v[10005],N,M;
void combag(int n,int m)
{
	for(int i=1;i<=n;i++)
	{
		for(int j=1;j<=m;j++)
		{
			if(w[i]<=j)
			{
				f[j]=max(f[j],f[j-w[i]]+v[i]);
			}
		}
	}
	printf("%d",f[m]);
	return;
}
int main(void)
{
	freopen("1.in","r",stdin);
	freopen("1.out","w",stdout); 
	scanf("%d%d",&M,&N);
	for(int i=1;i<=N;i++)
	{
		scanf("%d%d",&w[i],&v[i]);
	}
	combag(N,M);
	return 0;
}
