#include<bits/stdc++.h>
using namespace std;
struct party{
	int s,f;
}a[100086];
bool cmp(party a,party b)
{
	return a.f<b.f;
}
int n,ans=1;
int main()
{
	cin>>n;
	for(int i=0;i<n;i++)
		cin>>a[i].s>>a[i].f;
	sort(a,a+n,cmp);
	for(int i=1,j=0;i<n;i++)
		if(a[i].s>a[j].f)
		{
			ans++;
			j=i;
		}
	cout<<ans<<endl;
	return 0;
}
