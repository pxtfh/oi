#include<bits/stdc++.h>
using namespace std;
bool is_prime(int n)
{
	if(n<2)
	    return false;
	if(n==2)
	    return true;
	for(int i=2;i<=sqrt(n);i++)
	    if(n%i==0)
	        return false;
	return true;
} 
int l,r,x,y;
int a[10];
bool flog=true;
void chazhao(int x,int k)
{
	if(x==(k+1)/2)
	{
		for(int i=k;i>x;i--)
		    a[i]=a[k-i+1];
		int ans=0;
		for(int i=1;i<=k;i++)
		    ans=ans*10+a[i];
		if(ans<l)
		    return;
		if(ans>r)
		{
	        flog=false;
	        return;
		}
		if(is_prime(ans))
		    cout<<ans<<endl;
		return;
	}
	int i;
	if(x)
	    i=0;
	else
	    i=1;
	for(i=i;i<=9;i++)
	{
		if(flog==false)
		    return;
		a[x+1]=i;
		chazhao(x+1,k);
	}
	return;
}
int wei(int n)
{
	int m=n,sum=0;
	while(m>0)
	{
		m=m/10;
		sum++;
	}
	return sum;
}
int main()
{
   //freopen(".in","r",stdin);
   //freopen(".out","w",stdout);
   ios::sync_with_stdio(0);
   cin>>l>>r;
   x=wei(l);
   y=wei(r);
   for(int i=x;i<=y;i++)
   {
   	    if(i==1)
   	    {
   	    	if(l<=5&&r>=5)
   	    	    cout<<'5'<<endl;
   	    	if(l<=7&&r>=7)
   	    	    cout<<'7'<<endl;
   	    	continue;
		}
		if(i==2)
		{
			if(l<=11&&r>=11)
			    cout<<"11"<<endl;
			continue;
		}
		if(i%2==0)
		    continue;
		if(i==9)
		    break;
		flog=true;
		chazhao(0,i);
   }
   return 0;
}



