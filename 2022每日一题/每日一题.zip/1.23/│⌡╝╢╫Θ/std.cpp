#include<bits/stdc++.h>
using namespace std;
int maap[105][105];
int dx[5]={0,1,0,0,-1};
int dy[5]={0,0,1,-1,0};
int r,c,f[105][105],ans=0;
int dfs(int x,int y)
{
    if(f[x][y])
        return f[x][y];
    int tem=1;
    for(int i=1;i<=4;i++)
    {
        if(maap[x+dx[i]][y+dy[i]]<maap[x][y] && x+dx[i]>=1 && x+dx[i]<=r && y+dy[i]>=1 && y+dy[i]<=c)
            tem=max(dfs(x+dx[i],y+dy[i])+1,tem);
    }
    f[x][y]=tem;
    return tem;
}
int main()
{
    cin>>r>>c;
    for(int i=1;i<=r;i++)
    {
        for(int j=1;j<=c;j++)
            scanf("%d",&maap[i][j]);
    }
    for(int i=1;i<=r;i++)
    {
        for(int j=1;j<=c;j++)
        {
            int tem;
            tem=dfs(i,j);
            f[i][j]=tem;
            ans=max(tem,ans);
        }
    }
    cout<<ans<<endl;
    return 0;
}
