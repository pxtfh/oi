#include<bits/stdc++.h>
int n,ans=0,a1[2001]={6},shu[10]={6,2,5,5,4,5,6,3,7,6};
using namespace std;
int main()
{
	freopen("a.in","r",stdin);
	freopen("a.out","w",stdout);
        int i,j;
        cin>>n;
        for(i=1;i<=2000;i++)
        {
            j=i;
            while(j>=1)
            {
	            a1[i]+=shu[j%10];
                j=j/10;
            }
        }
        for(i=0;i<=1000;i++)
        {
            for(j=0;j<=1000;j++)
            if(a1[i]+a1[j]+a1[i+j]+4==n)
			    ans++;
        }
        cout<<ans;
        return 0;
}
