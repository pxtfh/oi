#include<bits/stdc++.h>
using namespace std;
int n;
bool b[14]={0},c[26]={0},d[26]={0};
int a[14],sum=0,flag=0;
void print()
{
	flag++;
	if(flag>3)
	{
		sum++;
		return;
	}
	sum++;
	for(int i=1;i<=n;i++)
		cout<<a[i]<<' ';
	cout<<endl;
	
}
int search(int o)
{
	for(int i=1;i<=n;i++)
	{
		if((!b[i])&&(!c[i+o])&&(!d[o-i+n-1]))
		{
			a[o]=i;
			b[i]=1;
			c[i+o]=1;
			d[o-i+n-1]=1;
			if(o==n)
				print();
			else
				search(o+1);
			b[i]=0;
			c[i+o]=0;
			d[o-i+n-1]=0;		
		}
	}
}
int main()
{
	//freopen(".in","r",stdin);
	//freopen(".out","w",stdout);
	ios::sync_with_stdio(0);
	cin>>n;
	search(1);
	cout<<sum;
	return 0;
}

