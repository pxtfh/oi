#include <iostream>
#include<cstdio>
#include<cmath>
using namespace std;
int sum=-100001,n,a[200005],f[200005];
int main(int argc, const char * argv[])
{
    cin>>n;
    for(int i=1;i<=n;i++)
    {
        scanf("%d",&a[i]);
        f[i]=max(f[i-1]+a[i],a[i]);
        sum=max(sum,f[i]);
    }
    cout<<sum;
    return 0;
}

