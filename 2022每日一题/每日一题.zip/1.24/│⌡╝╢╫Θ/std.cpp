#include<bits/stdc++.h>
using namespace std;
int n,m;
struct node
{
    int l;
    int r;
}a[100003];
void ar(int tem,int x)
{
    a[tem].l=x;
    a[a[x].r].l=tem;
    a[tem].r=a[x].r;
    a[x].r=tem;
}
void al(int tem,int x)
{
    a[tem].r=x;
    a[a[x].l].r=tem;
    a[tem].l=a[x].l;
    a[x].l=tem;
}
void shan(int x)
{
    if(a[x].l==-1)
        return;
    a[a[x].l].r=a[x].r;
    a[a[x].r].l=a[x].l;
    a[x].l=-1;
    a[x].r=-1;
}
void print()
{
    int x=a[0].r;
    while(1)
    {
        cout<<x<<' ';
        if(a[x].r==-1)
            break;
        x=a[x].r;
    }
}
int main()
{
    cin>>n;
    for(int i=1;i<=n;i++)
    {
        a[i].l=-1;
        a[i].r=-1;
    }
    a[1].r=-1;
    a[0].r=1;
    a[1].l=0;
    for(int i=2;i<=n;i++)
    {
        int tem1,tem2;
        cin>>tem1>>tem2;
        if(tem2==0)
            al(i,tem1);
        else
            ar(i,tem1);
    }
    cin>>m;
    for(int i=1;i<=m;i++)
    {
        int tem;
        cin>>tem;
        shan(tem);
    }
    print();
    return 0;
}

