#include<cstdio>
#include<queue>
using namespace std;
queue<int> q;
int map[3050][3050],vis[3050];
int t,n,a[3050],b;
int main()
{
	scanf("%d",&t);
	while(t--)
	{
		bool f=0;
		scanf("%d",&n);
		for(int i=1;i<n;i++)
			for(int j=i+1;j<=n;j++)
				scanf("%d",&map[i][j]);
		q.push(1);
		a[1]=0;
		vis[1]=1;
		while(!q.empty()&&!f)
		{
			b=q.front();
			q.pop();
			for(int i=b+1;i<=n;i++)
				if(map[b][i]==1)
					if(vis[i]==1&&a[i]==a[b])
					{
						f=1;
						break;
					}
					else if(vis[i]==0)
					{
						q.push(i);
						a[i]=b;
						vis[i]=1;
					}	
		}
		while(!q.empty())
			q.pop();
		for(int i=1;i<=n;i++)
			vis[i]=0,a[i]=0;
		q.push(1);
		a[1]=0;
		vis[1]=1;
		while(!q.empty()&&!f)
		{
			b=q.front();
			q.pop();
			for(int i=b+1;i<=n;i++)
				if(map[b][i]==0)
					if(vis[i]==1&&a[i]==a[b])
					{
						f=1;
						break;
					}
					else if(vis[i]==0)
					{
						q.push(i);
						a[i]=b;
						vis[i]=1;
					}	
		}
		while(!q.empty())
			q.pop();
		for(int i=1;i<=n;i++)
			vis[i]=0,a[i]=0;
		if(f)
			printf("Bad\n");
		else
			printf("Good\n");	
	}
	return 0;
} 
