#include<bits/stdc++.h>
using namespace std;
string s1,s2;
int a[5][3],b[5],n,ans=20;
int main()
{
	cin>>n;
	while(n--)
	{
		cin>>s1>>s2;
		for(int i=0;i<4;i++)
		{
			a[i][0]=s2[i]-s1[i];
			a[i][1]=a[i][0]+10>10?a[i][0]:a[i][0]+10;
			a[i][2]=a[i][0]-10<-10?a[i][0]:a[i][10]-10;
		}
		for(int i=0;i<81;i++)
		{
			int m=i;
			for(int j=0;j<4;j++)
			{
				b[j]=a[j][m%3];
				m=m/3;
			}
			int cnt=b[0]>0?b[0]:0;
			for(int j=0;j<4;j++)
				cnt+=b[j+1]-b[j]>0?b[j+1]-b[j]:0;
			if(cnt<ans)
				ans=cnt;
		}
		cout<<ans<<endl;
		ans=20;
	}
	return 0;
} 
