#include<iostream>
#include<cstdio>
using namespace std;
int f[155][10],n,k;
void init(void)
{
	for(int i=1;i<=k;i++)
	{
		f[i][i]=1;
	} 
	for(int i=1;i<=n;i++)
	{
		f[i][1]=1;
	}
	return;
}
int main(void)
{
//	freopen("���Ļ���.in","r",stdin);
//	freopen("���Ļ���.out","w",stdout);
	scanf("%d%d",&n,&k);//f[n][k]=f[n-1][k-1]+f[n-k][k];
	init();
	for(int i=2;i<=n;i++)
	{
		for(int j=2;j<=k;j++)
		{
			if(j>=i)	continue;
			else 	f[i][j]=f[i-1][j-1]+f[i-j][j];
		}
	}
	printf("%d\n",f[n][k]);
	return 0;
}
