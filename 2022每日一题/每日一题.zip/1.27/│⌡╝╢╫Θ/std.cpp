#include<bits/stdc++.h>
using namespace std;
char u[5]={0,0,1,0,-1};
int v[5]={0,1,0,-1,0};
int n;
char maap[35][35];
int flag[35][35];
void dfs(int x,int y)
{
    if(x<0 || x>n+1 || y<0 ||y>n+1 ||flag[x][y]!=0)
        return;
    flag[x][y]=1;
    for(int i=1;i<=4;i++)
        dfs(x+u[i],y+v[i]);
}
int main()
{
    cin>>n;
    for(int i=1;i<=n;i++)
        for(int j=1;j<=n;j++)
        {
            cin>>maap[i][j];
            if(maap[i][j]=='0')
                flag[i][j]=0;
            else
                flag[i][j]=2;
        }
    dfs(0,0);
    for(int i=1;i<=n;i++)
    {
        for(int j=1;j<=n;j++)
        {
            if(flag[i][j]==0)
                cout<<'W'<<' ';
            else if(flag[i][j]==1)
            	cout<<'0'<<' ';
            else
            	cout<<'M'<<' ';
        }
        cout<<endl;
    }
    return 0;
}

