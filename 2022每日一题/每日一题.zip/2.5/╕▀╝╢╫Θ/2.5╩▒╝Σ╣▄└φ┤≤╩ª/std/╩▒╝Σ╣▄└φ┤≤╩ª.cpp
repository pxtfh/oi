#include<iostream>
#include<cstdio>
#include<algorithm>
using namespace std;
struct nodes
{
	int l,r;
}num[100005];
bool vis[100005];
int n,ans;
bool cmp(nodes a,nodes b)
{
	if(a.r<b.r) return 1;
	return 0;
}
int main(void)
{
	freopen("�ߺ�.in","r",stdin);
	freopen("�ߺ�.out","w",stdout);
	scanf("%d",&n);
	for(int i=1;i<=n;i++) scanf("%d%d",&num[i].l,&num[i].r);
	sort(num+1,num+1+n,cmp);
	for(int i=1;i<=n;i++)
	{
		if(!vis[i])
		{
			vis[i]=1;
			ans++;
			for(int j=i+1;j<=n;j++)
			{
				if(num[j].l<num[i].r) vis[j]=1;
				else break;
			}
		}
	}
	printf("%d",ans);
	return 0;
}
