#include<bits/stdc++.h>
using namespace std;
#define MOD 998244353
int n;
int a[1000006];
long long ans;
int main()
{
//	freopen("t.in","r",stdin);
//	freopen("t.out","w",stdout);
	cin>>n;
	for(int i=0;i<n;i++)
		scanf("%d",&a[i]);
	sort(a,a+n);
	for(int i=0;i<n/2;i++)
	{
		ans+=((n-1-2*i)*(a[n-i-1]-a[i]))%MOD;
		ans%=MOD;
	}
	cout<<ans;
	return 0;
}

