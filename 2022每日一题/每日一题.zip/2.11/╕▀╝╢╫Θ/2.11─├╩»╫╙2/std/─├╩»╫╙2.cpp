#include<iostream>
using namespace std;
int main(void)
{
	freopen("a.in","r",stdin);
	freopen("a.out","w",stdout);
	int n,m;
	int t;
	cin>>t;
	while(t--){
		cin>>n>>m;
		if(n%(m+1)==0){
			cout<<"NO"<<endl;
		}
		else{
			cout<<"YES"<<endl;
		}
	}
	return 0;
 } 
