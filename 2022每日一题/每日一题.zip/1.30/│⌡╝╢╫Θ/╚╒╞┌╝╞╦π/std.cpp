#include<bits/stdc++.h>
using namespace std;
int rn[3][15]={{0,31,60,91,121,152,182,213,244,274,305,335,366},{0,31,59,90,120,151,181,212,243,273,304,334,365}};
int y,d;
int main()
{
	freopen("t.in","r",stdin);
	freopen("t.out","w",stdout);
	cin>>y>>d;
	int pd=1;
	if(y%100&&!(y%4)||!(y%400))pd=0;
	for(int i=1;i<=12;i++)
	{
		if(rn[pd][i]>=d)
		{
			cout<<i<<" "<<d-rn[pd][i-1];
			break;
		}
	}
	return 0;
}
// 31,28,31,30,31,30,31,31,30,31,30,31
