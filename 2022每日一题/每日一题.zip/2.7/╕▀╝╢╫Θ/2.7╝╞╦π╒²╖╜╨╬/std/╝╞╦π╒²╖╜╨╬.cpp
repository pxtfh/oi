#include<iostream>
#include<algorithm>
using namespace std;
int main(void)
{
	freopen("a.in","r",stdin);
	freopen("a.out","w",stdout);
	long long int x,y;
	int t;
	cin>>t;
	while(t--){
		long long int ans=0;
		cin>>x>>y;
		while(x&&y)
		{
			swap(x,y);
			ans+=x/y; 
			x%=y; 
		}
		cout<<ans<<endl;
	}
	return 0;
}
