#include<bits/stdc++.h>
using namespace std;
char a[32123123];
int num;
int main()
{
//	freopen("t.in","r",stdin);
//	freopen("t.out","w",stdout);
	gets(a);
	for(int i=0;i<strlen(a);i++)
	{
		if(a[i]<='9'&&a[i]>='0')
			num=num*10+a[i]-'0';
	}
	if(!num)
	{
		cout<<num;
		return 0;
	}
	for(int i=num-1;i>=2;i--)
	{
		if(num%i==0)
		{
			cout<<i;
			return 0;
		}
	}
	cout<<num;
	return 0;
}

