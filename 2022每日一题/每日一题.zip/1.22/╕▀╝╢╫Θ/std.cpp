#include<bits/stdc++.h>
using namespace std;
int ma[1024][1024],n,m,ans;
int dx[]={0,1,1,1,0,-1,-1,-1},dy[]={1,1,0,-1,-1,-1,0,1};
char c;
void dfs(int x,int y)
{
	ma[x][y]=0;
	for(int i=0;i<8;i++)
		if(ma[x+dx[i]][y+dy[i]]==1)
			dfs(x+dx[i],y+dy[i]);
}
int main()
{
	cin>>n>>m;
	for(int i=1;i<=n;i++)
		for(int j=1;j<=m;j++)
		{
			cin>>c;
			if(c=='#')
				ma[i][j]=1;
		}
	for(int i=1;i<=n;i++)
		for(int j=1;j<=m;j++)
			if(ma[i][j]==1)
			{
				ans++;
				dfs(i,j);
			}
	cout<<ans<<endl;
	return 0;
}
