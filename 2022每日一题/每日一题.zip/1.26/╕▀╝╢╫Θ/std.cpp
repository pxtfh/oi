#include<bits/stdc++.h>
using namespace std;
int main()
{
    int n,m,a;
    cin>>n>>m;
    a=n+m;
    if(a%2)
        cout<<"CYK"<<endl;
    else
        cout<<"XHX"<<endl;
    return 0;
} 
