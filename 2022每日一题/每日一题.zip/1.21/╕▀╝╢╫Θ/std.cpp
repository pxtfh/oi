#include<iostream>
#include<queue>
using namespace std;
int n,m,dx[4]={0,1,0,-1},dy[4]={1,0,-1,0};
char a[120][120];
bool b[120][120];
struct point{
	int x,y;
	int ans;
}p;
queue<point>q;
int main()
{
	freopen("t4.in","r",stdin);
	freopen("t4.out","w",stdout);
    cin>>n>>m;
    for(int i=0;i<n;i++)
    	for(int j=0;j<m;j++)
    	{
    		cin>>a[i][j];
    		if(a[i][j]=='#')
    			p.x=i,p.y=j,p.ans=0;
    	}
    
    q.push(p);
    b[p.x][p.y]=1;
    while(q.empty()!=1)
    {
    	p=q.front();
    	q.pop();
    	point p0;
    	for(int i=0;i<=4;i++)
    		if((p.x+dx[i]<0)||(p.x+dx[i]>n-1)||(p.y+dy[i]<0)||(p.y+dy[i]>m-1))
    			continue;
    		else
    		{
    			p0.x=p.x+dx[i],p0.y=p.y+dy[i],p0.ans=p.ans+1;
    			if(a[p0.x][p0.y]=='+'||b[p0.x][p0.y]==1)
    				continue;
    			b[p0.x][p0.y]=1;
    			if(a[p0.x][p0.y]=='@')
    			{
    				cout<<p0.ans;
    				return 0;
    			}
    			q.push(p0);
    		}
    }
    cout<<-1;
    return 0;
}
