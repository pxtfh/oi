#include<bits/stdc++.h>
using namespace std;
int n;
int main()
{
	freopen("t.in","w",stdout);
	srand(time(0));
//	n=1+rand()%100;
	n=100;
	cout<<n<<endl;
	for(int i=0;i<n;i++)
	{
		int a;
		a=1+rand()%5;
		cout<<3<<" ";
	}
	return 0;
}

