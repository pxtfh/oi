#include<bits/stdc++.h>
using namespace std;
int value[9999999];
long long n,a,ans,maxn,minn=1e6+5;
int main()
{
	cin>>n;
	for(int i=0;i<n;i++)
	{
		cin>>a;
		value[a]++;
		if(a>maxn)
			maxn=a;
		if(a<minn)
			minn=a;
	}
	for(int i=minn;i<=sqrt(maxn)+1;i++)
		if(value[i])
			for(int j=i;j<=maxn/i+1;j++)
				if(value[j]&&i*j<=maxn&&value[i*j])
					if(i!=j)
						ans+=2*value[i]*value[j]*value[i*j];
					else
						ans+=value[i]*value[j]*value[i*j];
	cout<<ans<<endl;
	return 0;
} 
