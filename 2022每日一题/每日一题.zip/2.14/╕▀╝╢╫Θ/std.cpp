#include<cstdio>
#include<cstring>
using namespace std;
char a[500050],b[500050];
int main()
{
    scanf("%s",a);
    int len=0,x=2,ans=0;
    for(int i=0;i<strlen(a);i++)
    {	
    	if(x==2&&a[i]=='[')
    	{
    		x=1;
    		continue;
		}
    	if(x==1&&a[i]==':')
    	{
    		x=0;
    		continue;
		}
		if(x==0)
			if(a[i]=='|'||a[i]==':'||a[i]==']')
    			b[len++]=a[i];	
	}
	b[len]='\0';
	x=2;
	for(int i=len;i>=0;i--)
	{
		if(x==2&&b[i]==']')
			x=1;
		if(x==1&&b[i]==':')
			x=0;
		if(x==0&&b[i]=='|')
			ans++;
	}
	if(x==0)
		printf("%d\n",ans+4);
	else
		printf("-1\n");
    return 0;
}
