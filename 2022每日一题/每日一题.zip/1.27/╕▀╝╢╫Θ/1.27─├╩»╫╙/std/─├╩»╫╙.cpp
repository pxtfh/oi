#include<iostream>
using namespace std;
int n;
unsigned long long int ans,sum;
int main(void)
{
	freopen("��ʯ��.in","r",stdin);
	freopen("��ʯ��.out","w",stdout);
	cin>>n;sum=0;
	for(int i=1;i<=n;i++)
	{
		cin>>ans;
		sum^=ans;
	}
	if(sum!=0) cout<<"YES"<<endl;
	else cout<<"NO"<<endl;
	return 0;
 } 
