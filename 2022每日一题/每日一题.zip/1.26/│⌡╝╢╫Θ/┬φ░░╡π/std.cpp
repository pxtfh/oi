#include<stdio.h>
int main()
{
//	freopen("t.in","r",stdin);
//	freopen("t.out","w",stdout);
	int pd,p,x,y,m,n,i,j,row,colum,max,min;
	scanf("%d %d",&m,&n);
	int a[200][200];
	int b[200],c[200];
	for(i=0;i<m;i++)
	{
		for(j=0;j<n;j++)
		{
			scanf("%d",&a[i][j]);
		}
	}
	for(i=0;i<m;i++)
	{
		min=a[i][0];
		for(j=0;j<n;j++)
		{
			if(a[i][j]<=min)
			{
				min=a[i][j];
				b[i]=min;
			}
		}
	}
	for(j=0;j<n;j++)
	{
		max=a[0][j];
		for(i=0;i<m;i++)
		{
			if(a[i][j]>=max)
			{
				max=a[i][j];
				c[j]=max;
			}
		}
	}
	for(i=0;i<m;i++)
	{
		x=b[i];
		for(j=0;j<n;j++)
		{
			if(c[j]==x)
			y=c[j];
		}
	}
	pd=0;
	for(i=0;i<m;i++)
	{
		for(j=0;j<n;j++)
		{
			if(a[i][j]==y)
			{
				row=i;
				colum=j;
				pd=1;
				p=a[i][j];   
			}
		}
	}
	if(pd==0)
		printf("no\n");
	if(pd==1)
		printf("%d %d %d",row,colum,p);
	return 0;
} 
